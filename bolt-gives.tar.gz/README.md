# Bolt.gives

[![Bolt.gives: AI-Powered Full-Stack Web Development](./public/social_preview_index.jpg)](https://bolt.gives)

**Powered by [OpenWeb Software Solutions](https://openweb.live)**

Welcome to Bolt.gives, a powerful AI-powered web development platform that allows you to choose the LLM for each prompt! Currently supports OpenAI (including GPT-5), Anthropic, Ollama, OpenRouter, Gemini, LMStudio, Mistral, xAI, HuggingFace, DeepSeek, and Groq models. Easily extensible to use any other model supported by the Vercel AI SDK!

This is a fork of the original bolt.diy project, enhanced and maintained by OpenWeb Software Solutions to provide superior AI-powered development experiences.

---

## 🌟 Enhanced Features

### What Makes Bolt.gives Special:

- **GPT-5 Support**: First-class support for OpenAI's GPT-5 model
- **Enhanced Performance**: Optimized Node.js memory allocation (3GB)
- **Professional Support**: Backed by OpenWeb Software Solutions
- **Regular Updates**: Continuously maintained and improved

---

## Quick Start

### Prerequisites

- Node.js 18+ (20+ recommended)
- pnpm package manager

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/embire2/bolt.gives.git
   cd bolt.gives
   ```

2. **Install dependencies**:
   ```bash
   npm install -g pnpm
   pnpm install
   ```

3. **Start development server**:
   ```bash
   pnpm run dev
   ```

4. **Open your browser** to `http://localhost:5173`

### Using Docker

```bash
docker build -t bolt-gives .
docker run -p 5173:5173 bolt-gives
```

---

## 🚀 Features

- **AI-powered full-stack web development** for NodeJS applications directly in your browser
- **Multiple LLM support** with GPT-5, Claude, Gemini, and more
- **Attach images** to prompts for better context
- **Integrated terminal** to view command outputs
- **Code versioning** with revert capabilities
- **Project export** as ZIP files
- **Docker integration** for easy deployment
- **Deploy directly** to Netlify, Vercel, and more

---

## 🎯 Supported AI Models

### OpenAI
- **GPT-5** (Featured) - 16K token context
- GPT-4o, GPT-4o Mini
- GPT-4 Turbo, GPT-4
- GPT-3.5 Turbo

### Other Providers
- Anthropic Claude (all variants)
- Google Gemini (Flash & Pro)
- Ollama (local models)
- Groq, xAI Grok, Mistral
- DeepSeek, HuggingFace
- OpenRouter (access to 100+ models)

---

## 📡 API Configuration

1. Select your preferred AI provider from the dropdown
2. Click the pencil icon to enter your API key
3. For custom base URLs (Ollama, LM Studio):
   - Go to Settings → Providers tab
   - Configure your custom endpoint

---

## 🏢 About OpenWeb Software Solutions

[OpenWeb Software Solutions](https://openweb.live) is a leading provider of AI-powered development tools and solutions. We specialize in:

- **AI Development Platforms**
- **Custom AI Solutions**
- **Enterprise AI Integration**
- **Open Source AI Tools**

### Contact & Support

- **Website**: [openweb.live](https://openweb.live)
- **Email**: support@openweb.live
- **Repository**: [github.com/embire2/bolt.gives](https://github.com/embire2/bolt.gives)

---

## 🔧 Available Scripts

- `pnpm run dev` - Start development server
- `pnpm run build` - Build for production  
- `pnpm run start` - Run production build
- `pnpm run preview` - Preview production build
- `pnpm test` - Run test suite
- `pnpm run typecheck` - TypeScript type checking
- `pnpm run lint:fix` - Fix linting issues

---

## 🐳 Docker Support

### Build and Run

```bash
# Development
docker build -t bolt-gives:dev --target bolt-ai-development .
docker run -p 5173:5173 bolt-gives:dev

# Production
docker build -t bolt-gives:prod --target bolt-ai-production .
docker run -p 5173:5173 bolt-gives:prod
```

### Docker Compose

```bash
docker-compose --profile production up
```

---

## 🤝 Contributing

We welcome contributions! This project builds upon the excellent foundation of bolt.diy while adding our own enhancements.

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

---

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- Original bolt.diy project by Cole Medin and the community
- StackBlitz team for the foundational technology
- The open source community for continuous improvements

---

## ⚠️ Commercial Licensing Notice

**WebContainer API Licensing**: This project uses WebContainers API which requires licensing for production commercial use. For commercial deployments, please ensure compliance with WebContainer licensing terms.

---

<div align="center">

**Enhanced and Maintained by**

[![OpenWeb Software Solutions](https://img.shields.io/badge/OpenWeb-Software%20Solutions-blue?style=for-the-badge)](https://openweb.live)

**Empowering developers with AI-powered tools**

</div>